import 'dart:async';
import 'package:flutter/material.dart';
import 'app.dart';

FutureOr<void> main() async {
  runApp(const App());
}